# Mehngai Matters

Research on how inflation affects Islamabad's middle class, plus a beginner's guide to investing in Pakistan.
Static site: plain HTML, CSS and JavaScript. No build step.

## Files
- `index.html`: home page
- `research.html`: the research, with charts (`charts.js`)
- `blog.html`: the investing guide
- `style.css`: all styling
- `.nojekyll`: tells GitHub Pages to serve files as-is

## Deploy on GitHub Pages
1. Commit these files to the root of your repo.
2. Repo **Settings → Pages**, set Source to *Deploy from a branch*, choose your branch and `/ (root)`.
3. Your site appears at `https://<username>.github.io/<repo>/`.

## Updating
- Survey numbers: edit the arrays at the top of each chart call in `charts.js`, and the heatmap table in `research.html`.
- Charts load Chart.js 4.4.7 from the jsDelivr CDN, so an internet connection is needed to view them.
